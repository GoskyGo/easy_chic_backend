<?php

return [

    'hello' => 'Olla',

];
